#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  trymonedero.py
#  
#  Copyright 2042 alexiskayro <alexiskayro@alexiskayro-Intel-powered-classmate-PC>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  


monedero = []

dato=raw_input("Instroduzca importe (euros):");

dato=dato.split('.')

try: parte_decimal =float('0.'+dato[1])
except: parte_decimal = 0.0

paret_entera = long(dato[0])

for i in billetes_y_monedas:
	unidades, resto=divmod(parte_entera,i)
if unidades != 0:
		 monedero.append((i,unidades))
		 parte_entero=resto
for i in billetes_y_monedas:
	  unidades,resto= divmod(parte_decimal,i)
if unidades != 0:
	  monedero.append((i,unidades))
	  parte_decimal = round(resto,2)
	  
	  cadena = ''
	  
for i in monedero:
		 if i[0] >= 5: cadena += '%d billete/s de %d euros' %(i[1],i[0])
		 if i[0] < 5: cadena += '%d moneda/s de %s euros'%(i[1],i[0])
cadena += '\n'
print cadena
