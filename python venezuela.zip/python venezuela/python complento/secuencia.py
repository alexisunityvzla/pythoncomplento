#!/urs/bin/ en v python

sec = range(8)

def add(x,y): return x+y