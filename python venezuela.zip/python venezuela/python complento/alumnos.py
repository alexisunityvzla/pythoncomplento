#!/urs/bin/env python

x = l

conta1 = 0;
conta2 = 0;

while x >=10:

   nota int(raw_input("Ingrese nota:"));

	if nota <= 7:

    	conta1 = conta1 + 1;
	else:

    	conta2 = conta2 + 1;


    	x =  x + l;
print "Cantidad de alumnos con  notas mayores o iguales a 7 ",conta1;
print "Cantidad de alumnos con notas menores a 7",conta2;