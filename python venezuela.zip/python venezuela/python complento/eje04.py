#!/urs/bin/env python

print "instroduce un numero:";

n=input();

print "instroduce otro numero:";

d=input();

n=n+1;
d=d+2;

print "el primer resultado es:",n;
print " el ultimo resultado es:",d;

