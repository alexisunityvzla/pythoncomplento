#!/urs/bin/env python

from math import pi


d=int(raw_input("selecciona un numero:"));

x=int(raw_input("selecciona otro numero:"));
f=int(raw_input("selecciona otro numero:"));
v=int(raw_input("selecciona el siguiente dtos:"));
if d==0:
  print "continua";
  
else:
  print "sigue los datos:";
  g=float(raw_input("selecciona el ultimo numero:"));
if f==0:
 print " ";

elif f==2:
 print "el siguiente:";
if x<0:

 print "aun han terminado";
else:

 print " datos terminado:";

print "los resultado seria de los datos:",d*x+f-g/v;
print "terminate";


