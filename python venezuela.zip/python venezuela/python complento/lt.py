#!/urs/bin/env python

x=int(input("instroduzca el primer numero:"));
l=int(input("instroduzca el segundo numero:"));
 

while x ==1:
  print x;
  print "_";



