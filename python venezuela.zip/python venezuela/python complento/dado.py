#!/urs/bin/env python

print "bienvenido el programa:"

i=int(raw_input("selecciona un numero:"))

dados=float(raw_input("selecciona un numero de dado:"))



if i <= dados:

 print "el numero de dado seria el numero 5:"

else:

 print "el numero de dado seria el numero 10:"


 numero="numero5"
 dados="g"+numero[3:]

print dados

while dado< len[numero5]:

 numero=numero5[dado]

 print numero

dado=dado+1