#!/urs/bin/env python

from math import pi

print "selecciona un numero:";

s1=int(raw_input());

print "selecciona otro numero:";

s2=int(raw_input());
 

print "el numero menor es:",s1;
print "el numero mayor es:",s2;
print "presiona la tecla";




    
    
    
    
    
    
    
