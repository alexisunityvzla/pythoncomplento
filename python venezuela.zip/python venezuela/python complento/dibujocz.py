#!/urs/bin/ env python

from math import pi

d2=int(raw_imput("selecciona un numero:"));

d3=int(raw_imput("selecciona otro numero:"));

if d2<d3:
 print "el numero es:",d2;
else:
 print "el numero es:",d3;

h1=int(raw_imput("selecciona el siguiente numero:"));

h2=int(raw_imput("selecciona el ultimo numero:"));

if h2>h1:
 print "el numero es:",h2;
else:
 print "el numero es:",h1;


print "ves el dibujo de la cruz:";
print"     ++ ";
print "    ++  ";
print "+++++++++";
print "    ++  ";
print"     ++ ";
print"     ++ ";

