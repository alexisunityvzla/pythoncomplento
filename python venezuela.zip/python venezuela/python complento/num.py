#!/urs/bin/env python


n=float(raw_input("numero de 1 al 20:"));


for n in range(1,21):
	
	print"numero",n;

