#!/urs/bin/ env python

n1 = float(raw_input("selecciona un numero:"));

n2 = float(raw_input("selecciona otro numero:"));

if n1<n2:

 print "el numero menor es:",n1;
else:
 print "el numero mayor es:",n2;

print"mira el dibujo cuadradro:";
print "+---------+";
print "!         !";
print "!         !";
print "!         !";
print "+---------+";