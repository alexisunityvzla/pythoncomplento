#!/urs/bin/env python 

num = int(raw_input("instroduzca un numero:"));

while num != 0:

 if num >= 0:

  print "positivo";

 else:

  print "negativo";

num =  int(raw_input("instroduzca otro numero:"));