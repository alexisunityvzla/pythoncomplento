#!/urs/bin/env python

nombre=int(raw_input("ingrese su nombre:"));
nota=int(raw_input("ingrese su nota"));

if nota>=4 :

 print "esta probado es:",nota;

