#!/urs/bin/env python

for m  in range(1,40,5):

  print m;



for m in range(2,56,1):

  print m;
