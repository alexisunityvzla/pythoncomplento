#!/urs/bin/env python 

for n1 in range(1,10):
 for n2 in range(20):

  print n1 
else:
 print n2

if n1<n2:

 print "el numero primos:",n1;

else:

 print "el numero no es primos:",n2;

