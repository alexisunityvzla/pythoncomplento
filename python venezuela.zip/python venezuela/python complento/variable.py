#!/urs/bin/python

print "escriba un numero:";

a= float(raw_input());

print "escriba otro numero:";

b=float(raw_input());

suma=a+b;
restar=a-b;
multi=a*b;
div=a/b;

print "la suma es:",suma;
print "la restar es:",restar;
print "la multiplicacion es:",multi;
print "la division es:",div;
