#!/urs/bin/ env python

from math import pi

cel=int(raw_input("cuanta tecla tiene un celular:"));

prt=int(raw_input("cuanta parte tiene un celular:"));

if cel <=5:

 print "numero de tecla es correcto:";

else:

 print  "numero  de tecla es incorrecto:";


 print "continua";

if prt<=10:

 print "numero de parte de celular es correcto:";

else:

 print "numero de parte de celular es incorrecto:";


print "el total de la tecla es:",cel;
print "el total de la parte de celular es:",prt;
print "pulsa la tecla";

print "++++++++++";
print "+        +";
print "+        +";
print "+        +";
print "+        +";
print "++++++++++";
print "+ + +  + +";
print "+  + + + +";
print "++++++++++";







