#!/urs/bin/env python

x = int(input("instroduzca un numero:"));
l = int(input("instroduzca otro numero:"));

x = l;

while x <=100:

 print "_",x,"#",l;

x = x + l;