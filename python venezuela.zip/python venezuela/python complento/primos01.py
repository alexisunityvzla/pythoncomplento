#!/urs/bin/env python


print "instroduzca los numeros primos:";
i=int(raw_input());

for i in range(2,100,4):

	print i

