#!/urs/bin/ env python

def adivina (x):

  

 p1=int(raw_input("adivina un numero  favoritos:"));

 p2=int(raw_input("adivina otro numero favoritos:"));

 pass
 
 if p1 in p2:

  print "el numero favoritos es:",p2;

 else:

  print "el numero no favoritos es:",p1;

  return adivina
