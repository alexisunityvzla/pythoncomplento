#!/urs/bin/env ruby

def fact(n) :

 if n == 0:
  print 1
 else:

  n * fact(n-1)

 return fact