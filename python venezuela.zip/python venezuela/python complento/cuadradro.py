#!/urs/bin/env python

num=int(raw_input("ingrese un numero:"));

print "al cuadradro es",num;

res=int(raw_input("ingrese otro numero:"));

print "al cuadradro es",res;

if res >= 13:
 
  print "suficiente";

else:

 print "no suficiente";
