#!/urs/bin/env python

n2=int(raw_input("ingrese un numero:"));

if n2%2==0:

 print "es par";

else:

 print "es impar";