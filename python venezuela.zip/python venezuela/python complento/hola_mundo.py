#!/urs/bin/ env python

print "hola_mundo";
print "como esta";
