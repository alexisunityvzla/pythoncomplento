#!/urs/bin/env python

n = int(raw_input("cuantos empleados tienes la empresas:"));

x = l;
conta1 = 0;
conta2 = 0;
gastos = 0;

while x <= n:

 sueldo = float(raw_input("Ingrese el sueldo del empleados:"));

if sueldo <= 300:

 conta1 = conta1 + 1;

else:

 conta2 = conta2 + 1;

 gastos = gastos + sueldo;

 x = x+l;
print "cantidad de empleados con sueldo entre 100 y 300:",conta1,"\n";
print "cantidad de empleados con sueldo mayor a 300:",conta2,"\n";
print "gastos total de la empresas en sueldo:",sueldo;
