#!/urs/bin/env python

from math import pi

def menu():
 while(opcion) !=1 or opcion not in "abc":
  print "cajero automatico:";
  print "a)ingresar dinero:";
  print "b)sacar dinero:";
  print "c) consultar saldo:";
 
  op=int(raw_input());
  
if len(opcion) != 1 or opcion not in "abc":

   print "solo puede escoger las letras:";
   
   print "a,b,o,c.intentelo de nuevo";

 return opcion()