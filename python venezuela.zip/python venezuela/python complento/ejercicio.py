#!/urs/bin/env python


print "digite numero circulo:";

l=(raw_input("selecciona la longitud:"));
r=(raw_input("selecciona el radio:"));

print "si la parte del circulo de dos iguales el resultado es:";
print " el total de la longitud es:",l;
print "el total del radio  es:",r;
print "finalizar"
