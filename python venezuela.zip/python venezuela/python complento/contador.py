#!/urs/bin/env python

for cc in range(5,1005):

   cc=cc+5;
   cd=cd-5;
  print "numero_c",cc;
  print"numero_d",cd;