#!/urs/bin/env python

n = 1
h = ''
while n <= 25:
 if n%2 != 0:
  h += '%i' %n;
  n += 1;
  print h;
 print "finalizar"