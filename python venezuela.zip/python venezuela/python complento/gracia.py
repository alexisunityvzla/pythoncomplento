#!/urs/bin/env python

print "digite un numero de gracia en la pantalla:"

gr=int(raw_input("selecciona un numero:"))

for gracia in 2 or 3:

  print "Gracias"

print "terminado!"

