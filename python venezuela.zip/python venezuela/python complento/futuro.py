#!/urs/bin/env python

ft1=int(raw_input("selecciona tu futuro:"));

f1=int(raw_input("selecciona tu otro futuro:"));

f2=int(raw_input("selecciona el ultimo futuro:"));

if ft1 <= 5:

 print  "tu futuro es correcto";

else:

 print "tu futuro no es correcto";

 print " el total de tu futuro es:",f1+f2-ft1;

 exit;