#!/urs/bin/ env python

def restar (res):

 pass
   
 print (restar,res (7-2))
 
 return restar