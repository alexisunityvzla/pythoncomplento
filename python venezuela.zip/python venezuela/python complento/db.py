#!/urs/bin/env python
from math import pi

print "ves el dibujo de la cruz:";
print"     ++   ";
print"    ++    ";
print" +++++++++ ";
print"    ++    ";
print"     ++   ";
print"     ++   ";