#!/urs/bin/env python

num=int(raw_input("instroduzca cual es par o impar:"));

if num%2==0:

    print "es par";
     	
else:

   print "es impar";