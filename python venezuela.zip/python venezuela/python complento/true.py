#!/urs/bin/env python

while True:
 linea = raw_input('>')

if linea[0] == '#':
    continue
if linea == 'fin':
    break

print linea
print 'terminado!'