#!/urs/bin/env python

print "selecciona numero:";

n1=(raw_input());

print "el resultado final es:",n1;