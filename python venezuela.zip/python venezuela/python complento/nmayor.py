#!/urs/bin/env python

num1=int(raw_input("numero 1:"));
num2=int(raw_input("numero 2:"));

if num1 > num2:

 print "es mayor que",num1,num2;

else:
    if num1 == num2:

      print " es igual que",num1,num2;

    else:

     print "es menor que",num1,num2;

print"";
print"otra manera:";

if num1 > num2:

 RESUL="mayor";

else:
    if num1 == num2:

     RESUL="igual";

    else:

     RESUL="menor";


print "el primer resultado es:",num1;
print "el segundo resultado es:",num2;
print "el tercer resultado es:",RESUL;
print "finalizar";