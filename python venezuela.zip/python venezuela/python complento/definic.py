#!/urs/bin/env python 

from math import pi

def hola(h,n,m):

 print "selecciona un numero:";

 h=int(raw_input());

 print "selecciona otro numero:";

 n=int(raw_input());

 print "selecciona el ultimo numero:";


 m=int(raw_input());

 print "resultado es:",n+h*m;

 return True