#!/urs/bin/ env python

from math import pi

a,b=0,1

while b<10:

    print b

    a,b=b,a+b

