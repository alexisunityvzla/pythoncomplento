#!/urs/bin/env python

print "digite el numero correcto:";

a = int(raw_input("selecciona un numero:"));

if a <= 56.78:

    print "verdad";
else:

    print "falso";

print "finalizar";

