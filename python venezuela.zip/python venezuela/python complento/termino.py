#!/urs/bin/env python

termino=str(input("instroduzca un numero:"));


while termino != 25:

 print" - ",termino;



