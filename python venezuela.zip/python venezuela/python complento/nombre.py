#!/urs/bin/env python

nombre=int(raw_input("Ingrese tu nombre:"));

while nombre==2:
 	


 print " no te conozco";