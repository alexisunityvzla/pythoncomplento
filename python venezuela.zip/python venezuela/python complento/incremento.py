#!/urs/bin/env python

def  hacer_incrementar(n):

 return lambda x: x+n

 f= hacer_incrementar(42)
 f(0)

 f(1)