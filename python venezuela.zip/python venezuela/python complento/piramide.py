#!/urs/bin/env python


p3=float(raw_input("selecciona la altura de la piramide:"));

a2=float(raw_input("selecciona la anchura de la piramide:"));

print "la altura es:",p3;
print "la anchura es:",a2;

