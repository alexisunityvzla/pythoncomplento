#!/urs/bin/env python

n=int(raw_input("cuantas personas hay:"));

x = l;
suma = 0;

while x <= n:
 
  altura=int(raw_input("Ingrese la altura:"));

  suma = suma + altura;
  x = x + l;
  promedio = suma / n;

print "altura promedio:",promedio;