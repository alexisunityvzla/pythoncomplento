#!/urs/bin/env python

n  = 1

while n <=25:
  print n;

 n += 1
