#!/urs/bin/env python

def repite_estribillo():

 muestra_estribillo()
 muestra_estribillo()