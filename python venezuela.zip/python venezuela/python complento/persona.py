#!/urs/bin/env python

x = 1;
suma = 0;
l=0;
n = int(raw_input("cuanta persona hay:"));



while x <= 2:

 altura = int(raw_input("Ingrese la altura:"));

 suma = suma + altura;
 x = x+ l;
 promedio = suma/n;
print "altura promedio ",promedio;