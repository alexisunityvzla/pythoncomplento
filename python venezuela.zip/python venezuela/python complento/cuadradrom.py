#!/urs/bin/env python

n1=float(raw_input("ingrese un numero:"));
p=float(raw_input("elevado a la potencia:"));


print "primero resultado:",p;
print "segundo resultado:",n1;
print "finalizar"
