#!/urs/bin/ env python

a=["gatos","ventanas","defenestrado"]

for x in a:

 print x,   len(x)