#!/urs/bin/env python

rd=int(raw_input("selecciona  la pieza abajo de la moto:"));
mt=int(raw_input("selecciona la pieza de adentro de la moto:"));



while mt<1:

 print m
if mt<=2:
 print "usted a seleccionado la mistad de la pieza:";

else:

 print "usted a seleccionado la mistad esta complento:";



print "resultando total de la pieza es:",rd*mt;
print "finalizar";