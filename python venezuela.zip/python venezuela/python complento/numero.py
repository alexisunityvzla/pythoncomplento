#!/urs/bin/env python

print "selecciona un numero:";

s1=int(raw_input());

print "selecciona otro numero:";

s2=int(raw_input());

print "el resultando de los numero:",s1+s2;