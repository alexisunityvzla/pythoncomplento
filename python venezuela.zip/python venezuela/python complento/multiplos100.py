#!/urs/bin/env python


n = 1;
h = 0;

while n >= 2:

 if n%3==0:

  print n;
  h+= 1;
  n+= 1;

print "\n entre 1 y 100 hay %i numero multiplos de 3 "%h