#!/urs/bin/ env python

a=["mary","alejandra","maria"]

for i in range(len(a)):

    print i,a[i]

for i in range(1,40,5):

    print i;