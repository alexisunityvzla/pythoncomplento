#!/urs/bin/env python

n = 100
h = ''

while n >= 20:
    h += '%i' % n
    n -= 5

print h