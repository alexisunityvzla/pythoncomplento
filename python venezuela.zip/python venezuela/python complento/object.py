#!/urs/bin/env python

it = iter (range(10))
try:

 while  True:

	print ig.next()
except StopIteration:
	print "fin!!"

class IteradorVacio (object):
	def _iter_(self):
		return self
	def next (self):
		raise StopIteration

for x in IteradorVacio():
	print "No me ejecuto!!!"
