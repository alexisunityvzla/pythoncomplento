#!/urs/bin/env python

p=0;
cp=0;
c=0;
n=0;
h=0;

h1=input("primer numero:");
h2=input("segundo numero:");

if h1 > h2:

  n=h2
  h=h1
else:

  n=h1
  h=h2

while n < h:

 n+= 1;

 if n == h:
    c+=1;
print n,

if n%2 == 0:

  cp += 1;
  p += n;
  

print "\n entre %i y %i hay %i numero siendo %i pares (h1,h2,c.cp)";
print "La suma de los pares es %i"%p
