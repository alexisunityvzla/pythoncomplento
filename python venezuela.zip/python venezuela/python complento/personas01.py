#!/urs/bin/env python


print "Cuanta persona hay:";

n=int(raw_input());

x=1;
suma=0;

while x <= n:

  print "Ingrese la altura:";

  altura=float(raw_input());
  suma=suma+altura;
  x=x+1;

  promedio=suma/n;

print "ALtura promedio:",promedio;

