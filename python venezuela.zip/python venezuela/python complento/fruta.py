#!/urs/bin/env python

indice = 0

while indice<len(fruta):
 
  letra = fruta[indice]

  print letra
  indice = indice+1