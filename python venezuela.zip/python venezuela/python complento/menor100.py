#!/urs/bin/env python

num=int(raw_input("escriba un numero entero:"));
print"";
if num > 100:
 print "el numero que usted ha escrito es mayor ha 100";
else:
 print "el numero que usted ha escrito es menor ha 100";
