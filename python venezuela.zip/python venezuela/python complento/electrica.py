#!/urs/bin/ env python 



print "selecciona el voltaje de corriente de electrica:";
w=int(raw_input());

print "selecciona la potencia por hora: kilowatt_hora:";
kwh=int(raw_input());

if w <= 10:

 print"el voltaje de electrica posee a IV=1.c/5(c/c)=1.c/5=1wall";

elif w==15:

 print" 1 kwh=(1000w)*(3600s)=3,6*10.6J";

elif kwh ==3600:

 print "verificar la corriente:";

 print "la velocidad de corriente  electrica es exacta";
else:

 print "la velocidad de corriente electrica  no es exacta";


 print "velocidad esta exacta";

 print "corriente electrica";
 print "el total del wall es:",w+3600*24/6;
 print "el total del kilowatt_hora es:",kwh+24*60-45.09;
 print "finalizar";
 