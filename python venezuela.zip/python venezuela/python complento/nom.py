#!/urs/bin/env python



n=int(raw_input("selecciona un numero de nombre:"));
a=int(raw_input("selecciona un numero de apellido:"));

if n==2:

 print "te falta nombre:";

elif n+a==0:

 print "te falta apellido:";

 print "continua";
else:

 print "finalizar";

 print"listo";



 print "el total de los nombre es:",n+2+12;


 print"el total de los apellidos es:",a+3+3;