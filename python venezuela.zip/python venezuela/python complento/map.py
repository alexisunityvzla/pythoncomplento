#!/urs/bin/ env python

def cubo(x):
 
 
 pass
  
 print map(cubo,range(1,11))

 return x*x*x