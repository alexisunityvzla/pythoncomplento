#!/urs/bin/env python

def argc,argv:

 if argc == 0:
    print "Linea de comando no disponible";
    else:
      print "El programa esta corriendo",argc[i];
    if argc == 1:
    else:
     print "Argumento no recibidos en las Linea de comando.";
    else:
     print "Argumento de la Linea de comando";

    for int i=1;i<argc:i++:
    print argv[i];

return argc