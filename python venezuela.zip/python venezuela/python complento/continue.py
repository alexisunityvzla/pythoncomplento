#!/urs/bin/env python

def continua():

   c=0;
   for c in range(1,8):
    if i == 3:
		i ==5;
    continue;
    sum += i;
    
    print " la suma de 1,2,3,4,5,6 y 7 es:",sum;
