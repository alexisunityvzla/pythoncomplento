#!/urs/bin/ env python

def calcular (x):
 


 range(x+5)

if x in y:

 print "para calcular el resultado:";

elif x<=5:
    print (x,y(5+2));
else:
 print "calcular la otra diferencia:";
 

 pass


if y in x:
 
 print "diferencia:";

elif y==2:

 print (x,y(5*2));

 print "finalizar el resultado es",x5*y2;

 
 return calcular