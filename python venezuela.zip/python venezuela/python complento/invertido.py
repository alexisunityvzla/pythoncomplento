#!/urs/bin/env python

n1=int(raw_input("primer numero:"));
n2=int(raw_input("segundo numero:"));
rev1=int(raw_input("tercer numero:"));
rev2=int(raw_input("cuarto numero:"));

rev1=n1/10;
rev1=n1%10;
rev2=n2/10;
rev2=n2%10;

print "primer numero:",n1;
print "segundo numero:",n2;
print "tercer numero:",rev1;
print "cuarto numero:",rev2;

