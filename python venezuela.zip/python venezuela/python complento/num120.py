#!/urs/bin/env python

n = 48
h = '';

while n <= 120:

 h += '%i' % n
 n += 4
print h

n