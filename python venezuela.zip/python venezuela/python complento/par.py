#!/urs/bin/env python


n1 = int(raw_input("introduzca un numero:"));
n2 = int(raw_input("instroduzca otro numero:"));

if n1 >= 0:

  print "es par";

else:

  print "es impar";

if n2%2==0:

 print "es par";
     	
else:

   print "es impar";
