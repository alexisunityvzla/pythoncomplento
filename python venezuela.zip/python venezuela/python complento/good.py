#!/urs/bin/env pthon

def bueno_fucion():
  """
  Documentacion.

  """
  print "Funcion de"+_name_