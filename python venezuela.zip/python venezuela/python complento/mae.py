#!/urs/bin/ python

from math import pi

n1=int(raw_input("selecciona un numero:"));
v1=int(raw_input("selecciona otro numero:"));

d=["avion","elicoptero","moto"]

while n1<1:
 
 print n1
else:
 print v1

for ss in d:

  print ss, len(ss)

print "el total es:",n1+23;
print "el total es:",v1-5;

