#!/urs/bin/env python

amigos["joseph","glen","sally"]
for amigo in amigos:
 print "Feliz Año nuevo:",amigos;
 print "¡terminado!"