#!/urs/bin/env python

h = range(1,51)

print sum(h)