#!/urs/bin/env python

def fucion():

 print "hola_mundo";

 print "*** has probado!!";

fucion()