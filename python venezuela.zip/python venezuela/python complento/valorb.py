#!/urs/bin/ env python

a,b=0,1

while b<10:

 print b

a,b=a+b