#!/urs/bin/env python

resul="";
i="";
resul=input("digite un numero:");
num=input("digite otro numero:");
i=input("digite el ultimo numero:");




for num in range(1,12):

 resul=num * i;
 
print "la tabla de multiplicar es:",i,"*",num,"=",resul;

