#!/urs/bin/env python

from math import pi

print "selecciona un numero:";

x=int(raw_input("ingrese un numero entero por favor:"));

if x<0;
 x=0;

 print "negativo ha cambiando a cero";
 elif x==0;
 print "cero";
 elif x==1;
 print "uno";
 print "simple";

 else:
     print "mas";
