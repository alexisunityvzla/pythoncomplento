#!/urs/bin/env python

def bad_funcion():

 print "hola_mundo";