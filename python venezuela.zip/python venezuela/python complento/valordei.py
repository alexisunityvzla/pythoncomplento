#!/urs/bin/ env python

i=256*256

print "el valor de i es:",i;
