#!/urs/bin/env python

hr=int(raw_input("selecciona las horas:"));

mt=int(raw_input("selecciona los minutos:"));

sd=int(raw_input("selecciona los segundos:"));


if hr < mt:

 print " horas esta correcto:";

else:

 print "horas esta incorrecto:";



 