#!/urs/bin/env python

cont=0;
h=(raw_input("ingrese un numero:"));

cont/7;
while h > 4:

	
  print "elresultado final es",h;

