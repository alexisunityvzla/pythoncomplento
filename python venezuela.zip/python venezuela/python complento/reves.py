#!/urs/bin/env python


print "ingrese dos numero de 2 digitos:";

n=int(raw_input());
rpta=int(raw_input());

c=n/10;
c=n%10;
rpta=c+10;

print "el numero reves es:",rpta;