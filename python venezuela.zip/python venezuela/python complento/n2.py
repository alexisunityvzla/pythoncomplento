#!/urs/bin/env python

if __name__ == '__main__':

    for n in range(1,44,4):
	 print n
