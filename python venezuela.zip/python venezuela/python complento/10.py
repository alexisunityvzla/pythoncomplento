#!/urs/bin/env python

def fucion(n):

	print "ingrese un numero:";

	n=int(raw_input());

for n in range(1,11):
   
   print n;



