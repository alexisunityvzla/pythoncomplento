#!/urs/bin/env python

def fact:

 if n == 0:

 1
 else:

 n * fact(n-1)

 return fact

print fact(ARVG[0].to_i), "\n"