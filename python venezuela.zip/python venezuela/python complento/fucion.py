#!/urs/bin/ env python

def mi_fucion():


 pass

 print mi_fucion._doc_