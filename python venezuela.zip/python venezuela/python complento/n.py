#!/urs/bin/env python

n=int(raw_input("Ingrese el valor final:"));



while n != 2:

 print "_",n;
