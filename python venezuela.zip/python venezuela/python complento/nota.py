#!/urs/bin/env python

nota1 =int(raw_input("ingrese primera nota:"));
nota2 =int(raw_input("ingrese segunda nota:"));
nota3 =int(raw_input("ingrese tercer nota:"));

prom =(nota1+nota2+nota3)/3

if prom >= 7:

 print "promocionado";
else:
 if prom >= 4:
  print "regular";
 else:
  print "reprobado";

  print "finalizar";
