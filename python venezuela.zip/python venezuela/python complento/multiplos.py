#!/urs/bin/env python


num = 5;

while num <= 100:

 
 print "multiplos es",num;

num = num + 5;

