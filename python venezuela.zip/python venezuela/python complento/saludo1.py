#!/urs/bin/env python

print "digite el saludo de tu preferencia:"

saludos=["hola_tio","hola_compa","hola_mundo"]

for saludo in saludos:

  print  "me gusta tu ",saludos;

  print "siguente"


  palabra="python"

  cuenta=0
  
for palabra in saludo:
 if saludo == saludos:

  cuenta=cuenta+2

  print cuenta
  