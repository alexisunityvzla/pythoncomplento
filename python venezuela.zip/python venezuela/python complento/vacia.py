#!/urs/bin/env python


def sum(sec):

    

   def sumar(x,y): return x+y
   
 