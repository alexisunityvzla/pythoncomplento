#!/urs/bin/env python

print "numero 1:";

num1 = int(raw_input());

print "numero 2:";

num2 = int(raw_input());

RESUL = (num1+num2)*(num1-num2);

print "";
print "el resultado es:",RESUL;
print "finalizar";