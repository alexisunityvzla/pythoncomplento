#!/usr/bin/ env python

from math import pi

print "selecciona la bases:";

bs=int(raw_input());

print "selecciona la altura:";

alt=int(raw_input());

print "selcciona el ancho:";

ach=int(raw_input());

print "el ultimo";

s=int(raw_input());

s=(ach+bs+alt)/2.0;

s=12;
s=4;


print "el area del triangulo es:",bs*alt+ach;

