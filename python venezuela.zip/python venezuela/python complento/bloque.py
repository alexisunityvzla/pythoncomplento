#!/urs/bin/ env python


	
encimap=int(raw_input("instroduce el primer numero de bloque:"));
mapcar=int(raw_input("instroduce el segundo numero de bloque:"));
  
if encimap < 7.08 :
	
	encimap=encimap+1;
	
	if mapcar > 8.09:
		
		mapcar=mapcar+1;
		
	else:
	 
	 mapcar=encimap/2;
	   
	   
for member in range(1,4):
	  
	  car=int(raw_input ("instroduce el ultimo numero:"));
	  car=car+2;
	  print "el resultado es:",car;

print "el primer resultado es:",encimap;
print "el segundo resultado es:",mapcar;

print "finalizar";


