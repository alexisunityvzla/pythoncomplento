#!/urs/bin/env python



r = int (raw_input("selecciona un numero de radio:"));
l = int (raw_input("selecciona un numero de longitud:"));
if l <= 12.09:

	print "es verdadero";

else:

  print "es falso";

if r > 34.09:

 print " es falso";

else:

 print " es verdadero";

print "el resultado de la circunferencia es:";
print "la longitud:",l;
print "radio :",r;
print "finalizar";




