
print saludo = "¡hola,mundo!";

nuevo_saludo = "j"+saludo[1:]
print nuevo_saludo;