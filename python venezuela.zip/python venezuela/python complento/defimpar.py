#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  defimpar.py
#  
#  Copyright 2042 alexiskayro <alexiskayro@alexiskayro-Intel-powered-classmate-PC>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  


def impar():
	
	print "instroduzca un numero:"
	num=input();
	print "instroduzca el ultimo numero:"
	n=input();
	
try: num=num*8.9;
 
except:impar=20*9.8

if impar%3==0:
	impar=impar+1;
	print "es impar"
 
else:
	impar=impar+1;
	print " es par"
print "el ultimo resultado es:",impar;
