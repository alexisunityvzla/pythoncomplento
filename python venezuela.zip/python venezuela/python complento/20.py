#!/urs/bin/env python

n = 1
h = 1

while n <= 20:
    h *= n
    n += 1
print h