#!/urs/bin/env python

def pares():

   num=input("instroduzca un numero:");
   
   if num%2==0:
      print "Este numero es par"
   else:
      print "Este numero es impar"
      
      
