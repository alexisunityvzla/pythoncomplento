#!/urs/bin/env python

fruta=int(raw_input("selecciona una fruta:"))
car=int(raw_input("selecciona un car:"))
for car in fruta2:
  print car+fruta

  