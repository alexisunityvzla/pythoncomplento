#!/urs/bin/env python

d=int(raw_input("instroduzca dia:"));
m=str(raw_input("instroduzca mes:"));

if d < 7:
   
   print "dia esta correcto";
else:

  print "el dia no esta correcto";

if m > 30:

	print "el mes esta correcto";

else:

	print "el mes no esta correcto";

print "el resultado primer dia es:",d;
print "el resultado segundo mes es:",m;