#!/urs/bin/env python

nombre=str(raw_input("ingrese nombre:"));
edad=str(raw_input("ingrese edad:"));
cedula=str(raw_input("ingrese cedula:"));
casado=str(raw_input("ingrese casado (s/n):"));

print "nombre es:",nombre;
print "edad es:",edad;
print "cedula es:",cedula;
print "casado es:",casado;
