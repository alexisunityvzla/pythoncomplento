#!/urs/bin/env python

palabra = "banana"

contador = 0

for letra in palabra:
 if letra == "a":
   contador = contador+1

   print contador