#!/urs/bin/env python

from math import pi 

def ventadequeso(tipos,argumentos1,palabrasclaves):

  print "tiene",tipos
  print "quiere",argumentos1
  print "__lo siento,nos quedamos sin",kind

for b in  argumentos:

 

 print b,":",argumento[b]

 print "_"*40

 claves=palabrasclaves.keys()
 claves.sort()

for x in claves:

 print c,":",palabrasclaves[c]

 ventadequeso("limbugue","es muy liquido,sr",
 
    "Realmente es muy liquido,sr.",
    cliente="juan garcia",
    vendedor="miguel perez",
    puesto="venta de queso argentino")


