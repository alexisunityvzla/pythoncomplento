 #!/urs/bin/env python

def pedir_confirmacion(prompt, reitento=4,quejas="si o no,por favor"):

 print "digite el numero:";
 
while True:

 OK=intraw_input(prompt)

 print "continua";
if OK in ("s","S","si","Si","SI"):

 print "siguente";
 return True

 print "verdadero";

if OK in ("n","no","nO","NO"):

 print "finalizar";
 return False

 print "finalizar";

 reitento=reitento-1

 print "final";

if reitento <0:

    raise IOError("usuario duro")

print quejas

 return pedir_confirmacion()


