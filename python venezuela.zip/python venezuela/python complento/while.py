#!/urs/bin/env python

n=5

while n > 0:
   
    print n

    n = n-1

print "despegue!"


n=10
while True:

 print n,

 n = n-1

 print "terminado!";