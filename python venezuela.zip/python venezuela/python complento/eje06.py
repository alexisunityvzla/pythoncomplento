#!/urs/bin/env python

from math import pi

def par (n2) :

 print "ingrese un numero:";

 n2=int(raw_input());

 if n2%2==0:

  print "es par";

 else:

  print "es impar";

 return pars