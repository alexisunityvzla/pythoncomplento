#!/urs/bin/env python

n=2

while n <= 10:
 
 print n

n+=2