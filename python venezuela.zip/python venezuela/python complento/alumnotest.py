#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  classnota.py
#  
#  Copyright 2018 alexiskayro <alexiskayro@alexiskayro-Intel-powered-classmate-PC>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
# 
#  
import unittest
from StringIO import StringIO

from personas import alumno

class alumnotest (unittest.TestCase) :

def test_unit (self):
	
	a = alumno (nombre="pepe",curso="1")
	self.assertEqual (a.nombre,"pepe")
	self.assertEqual  (a.curso,"1")


class alumnoIOtest (unittest.TestCase):
	
	def setUp (self):
		
		self.file = stringIO (
		
		"alumno1\ncurso1\nalumno2\ncurso2\nalumno3\ncurso3")
		
		def test-uno (self):
		a = alumno ()
		a.lee_datos (self.file)
		self.assertEqual (a.nombre,"alumno1")
		self.assertEqual (a.curos,"curso1")
		
		def test_dos (self):
			a = alumno ()
			a.lee_datos (self.file)
			self.assertEqual (a.nombre,"alumno2")
			self.assertEqual  (a.curso,"curso2")
			
			def test_tres (self):
				
				a = alumno ()
				a.lee_datos (self.file)
				self.assertEqual (a.nombre,"alumno3")
				self.assertEqual (a.curso,"curso3")
