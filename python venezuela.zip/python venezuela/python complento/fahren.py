#!/urs/bin/env python

ent = raw_input("instroduzca la temperatura fahrenheit:")

try:

 far = float(ent)
 cel = (fahr-32.0)*5.0/9.0

 print cel

except:

  print "Por favor,instroduzca un numero"