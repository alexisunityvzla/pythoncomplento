#!/urs/bin/env python

for n in range(2,10):
 print "x";
 for x in range(2,n):
  print "n";
if n/x==0:
  print n,"es igual a",x,"*",n/x;
else:
  print "**";
  
if x==1:
  print x,"es un primo";
else:

 print n,"es un numero primo";